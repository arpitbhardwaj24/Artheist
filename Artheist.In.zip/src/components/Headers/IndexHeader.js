/*eslint-disable*/
import React from "react";
import logo from "../../assets/img/now-logo.png";
// reactstrap components
import { Container } from "reactstrap";
// core components

function IndexHeader() {
  let pageHeader = React.createRef();

  React.useEffect(() => {
    if (window.innerWidth > 991) {
      const updateScroll = () => {
        let windowScrollTop = window.pageYOffset / 3;
        pageHeader.current.style.transform =
          "translate3d(0," + windowScrollTop + "px,0)";
      };
      window.addEventListener("scroll", updateScroll);
      return function cleanup() {
        window.removeEventListener("scroll", updateScroll);
      };
    }
  });

  return (
    <>
      <div className="page-header clear-filter" filter-color="blue">
        <div
          className="page-header-image"
          style={{
            backgroundImage: "url(" + require("assets/img/bg.jpeg") + ")"
          }}
          ref={pageHeader}
        ></div>
        <Container>
          <div className="content-center brand" style={{paddingTop:100}}>
          <img src={logo} className="logo" style={{
    width: 80,
    height: 80,
    marginBottom: 20
}}/>
            <h1 className="h1-seo" style={{fontWeight:380}}>Welcome to Artheist.in !</h1>
            {/* <h3>A beautiful Bootstrap 4 UI kit. Yours free.</h3> */}
            <p style={{fontWeight:400}}>Artheist is #1 contest aggregation platform for people pursuing their interest either in visual,
performance or applied arts.</p>

          </div>
          
        </Container>
      </div>
    </>
  );
}

export default IndexHeader;
