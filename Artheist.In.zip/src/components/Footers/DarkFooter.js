/*eslint-disable*/
import React from "react";

// reactstrap components
import { Container,Row, Col } from "reactstrap";

function DarkFooter() {
  return (
    <footer className="footer" data-background-color="black">
      <Container>
        {/* <nav>
          <ul>
            <li>
              <a
                href="https://www.creative-tim.com?ref=nukr-dark-footer"
                target="_blank"
              >
                Creative Tim
              </a>
            </li>
            <li>
              <a
                href="http://presentation.creative-tim.com?ref=nukr-dark-footer"
                target="_blank"
              >
                About Us
              </a>
            </li>
            <li>
              <a
                href="http://blog.creative-tim.com?ref=nukr-dark-footer"
                target="_blank"
              >
                Blog
              </a>
            </li>
          </ul>
        </nav> */}

        <Row>
          <Col sm="12" md={{ size: 6, offset: 3 }}>
            <div
              className="copyright .col-sm-12 .col-md-6 .offset-md-3 text-center"
              id="copyright"
            >
              © {new Date().getFullYear()}, Designed by{" "}
              <a
                href="https://www.invisionapp.com?ref=nukr-dark-footer"
                target="_blank"
              >
                Artheist.in
              </a>
              . Coded by{" "}
              <a
                href="https://www.creative-tim.com?ref=nukr-dark-footer"
                target="_blank"
              >
                Creative Tim
              </a>
              .
            </div>
          </Col>
        </Row>
      </Container>
    </footer>
  );
}

export default DarkFooter;
