import React from "react";
import "../assets/css/app.css";
import { Button, Form, FormGroup, Label, Input, FormText } from "reactstrap";

import example from "../assets/img/example.jpeg";
// reactstrap components
// import {
// } from "reactstrap";

// core components
import IndexNavbar from "components/Navbars/IndexNavbar.js";
import IndexHeader from "components/Headers/IndexHeader.js";
import DarkFooter from "components/Footers/DarkFooter.js";

function Index() {
  React.useEffect(() => {
    document.body.classList.add("index-page");
    document.body.classList.add("sidebar-collapse");
    document.documentElement.classList.remove("nav-open");
    window.scrollTo(0, 0);
    document.body.scrollTop = 0;
    return function cleanup() {
      document.body.classList.remove("index-page");
      document.body.classList.remove("sidebar-collapse");
    };
  });
  return (
    <>
      <IndexNavbar />
      <div className="wrapper">
        <IndexHeader />
        <section className="about">
          <h2>What We Do ?</h2>
          <p>
            We organize contests with well-known artists from Instagrams, ad
            firms & different social media handles to promote the skills/talent
            of skilled people like you.
          </p>
          <h4> Guess what!</h4>
          <p>
            {" "}
            Through each contest one of the famous artists on social media who
            will be the judge of the competition will be featured along with the
            top winners on their social media & will also get a chance to
            showcase their talent, which will not only give you praise but
            rather people who like your art would like to join/connect with you
            and see more of your art.
          </p>
        </section>
        <section className="example">
          <div className="e1">
            <h2>Example</h2>
            <h3>You look curious, look at the example...</h3>
            <p>
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Et
              voluptate repellendus, dolorem illum explicabo minus possimus.
              Cum, est quo perspiciatis dolores libero cumque maiores dolorem
              nisi et provident asperiores atque.
            </p>
          </div>
          <div className="e2">
            <img src={example} />
          </div>
        </section>

        <section className="form">
          <h2 style={{ paddingTop: 50, paddingBottom: 40 }}>
            Subscribe quickly for Early Benifits!!!
          </h2>

          <Button className="form-btn">Subscribe</Button>
          {/* <Form>
            <FormGroup>
              <Label for="Name" style={{maxWidth:500,margin: '0 auto'}}>Name</Label>
              <Input style={{maxWidth:500,margin: '0 auto'}}
                type="text"
                name="name"
                id="Name"
                placeholder="Enter Your Name"
              />
            </FormGroup>
            <br />
            <FormGroup>
              <Label for="Email">Email</Label>
              <Input style={{maxWidth:500,margin: '0 auto'}}
                type="email"
                name="email"
                id="Email"
                placeholder="Enter Your Email"
              />
            </FormGroup> 
            <br />      
            <FormGroup>
              <Label for="PhoneNo">Whatsapp No.</Label>
              <Input style={{maxWidth:500,margin: '0 auto'}}
                type="number"
                name="Number"
                id="Number"
                placeholder="Enter Your Number"
              />
            </FormGroup>
            <br />
            <FormGroup>
              <Label for="City">City</Label>
              <Input style={{maxWidth:500,margin: '0 auto'}}
                type="text"
                name="city"
                id="City"
                placeholder="Enter Your City"
              />
            </FormGroup> 
            <br />      
            <FormGroup>
              <Label >Select Skills</Label>
              <br />
              </FormGroup>
              <FormGroup check>
        <Input type="checkbox" name="check" id="Check" style={{opacity:1,visibility:"visible",marginLeft:15}}/>
        <Label for="Check" check>Check me out</Label>
      </FormGroup>
      <FormGroup check>
        <Input type="checkbox" name="check" id="Check" style={{opacity:1,visibility:"visible",marginLeft:15}}/>
        <Label for="Check" check>Check me out</Label>
      </FormGroup>
      <FormGroup check>
        <Input type="checkbox" name="check" id="Check" style={{opacity:1,visibility:"visible",marginLeft:15}}/>
        <Label for="Check" check>Check me out</Label>
      </FormGroup>
<br />
      <FormGroup>
              <Label >Select Interests</Label>
              <br />
              </FormGroup>
              <FormGroup check>
        <Input type="checkbox" name="check" id="Check" style={{opacity:1,visibility:"visible",marginLeft:15}}/>
        <Label for="Check" check>Check me out</Label>
      </FormGroup>
      <FormGroup check>
        <Input type="checkbox" name="check" id="Check" style={{opacity:1,visibility:"visible",marginLeft:15}}/>
        <Label for="Check" check>Check me out</Label>
      </FormGroup>
      <FormGroup check>
        <Input type="checkbox" name="check" id="Check" style={{opacity:1,visibility:"visible",marginLeft:15}}/>
        <Label for="Check" check>Check me out</Label>
      </FormGroup>

            
             */}

          {/* </Form> */}
        </section>
        <DarkFooter />
      </div>
    </>
  );
}

export default Index;
